Repository of the Bilan hydrological model.

To install use

```
devtools::install_bitbucket("hanelm/bilan", auth_user = "YOUR-USERNAME", password = "YOUR-PASSWORD")
```
