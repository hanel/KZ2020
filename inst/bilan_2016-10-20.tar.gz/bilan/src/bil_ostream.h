#ifndef BIL_OSTREAM_H_INCLUDED
#define BIL_OSTREAM_H_INCLUDED

#include <Rcpp.h>

#ifndef BIL_OSTREAM
#define BIL_OSTREAM Rcpp::Rcout
#endif

#endif // BIL_OSTREAM_H_INCLUDED
