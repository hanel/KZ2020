#ifndef BILANR_H_INCLUDED
#define BILANR_H_INCLUDED

#include <Rcpp.h>

#include "bil_ostream.h"
#include "bil_modif.h"

/**
 * - Bilan model with modified structure and containing R functions
 */
class bilan_Rmodif : public bilan_modif
{
  public:
    bilan_Rmodif(bilan_type type, unsigned modif_types); //!< sets modification types
    bilan_Rmodif(bilan_type type, unsigned modif_types, unsigned period); //!< sets modification types and period
    void resize_char_fun(unsigned size) { this->char_fun.resize(size); };
    void set_char_fun(SEXP char_fun, unsigned pos) { this->char_fun[pos] = char_fun; };

  private:
    virtual double calc_var_char(unsigned pos, bool is_observed); //!< calculates characteristics of given variable

    std::vector<SEXP> char_fun;
};

#endif // BILANR_H_INCLUDED
